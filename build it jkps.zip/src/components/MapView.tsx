import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Shield, Heart, Siren, Building2, MapPin, Plus, Minus, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface MapViewProps {
  userLocation: { lat: number; lng: number } | null;
  gpsStatus: "checking" | "granted" | "denied";
  onEnableLocation: () => void;
}

type MarkerType = "safe" | "hospital" | "police" | "fire" | "shelter" | "user";

interface MapMarker {
  id: string;
  type: MarkerType;
  lat: number;
  lng: number;
  label: string;
  detail: string;
}

const DELHI_CENTER: [number, number] = [28.6139, 77.209];

const markers: MapMarker[] = [
  { id: "1", type: "safe", lat: 28.6139, lng: 77.209, label: "Safe Zone — Connaught Place", detail: "Capacity: 500 people · Staffed 24/7" },
  { id: "2", type: "hospital", lat: 28.6304, lng: 77.2177, label: "AIIMS Hospital", detail: "Emergency department open 24/7" },
  { id: "3", type: "police", lat: 28.6186, lng: 77.2153, label: "Parliament Street Police Station", detail: "Response team active" },
  { id: "4", type: "fire", lat: 28.6562, lng: 77.241, label: "Fire Station — Civil Lines", detail: "3 units available" },
  { id: "5", type: "shelter", lat: 28.5355, lng: 77.391, label: "Shelter — Noida Sector 12", detail: "Capacity: 200 people · Food available" },
  { id: "6", type: "safe", lat: 28.5562, lng: 77.1, label: "Safe Zone — Dwarka", detail: "Capacity: 800 people · Medical staff on site" },
  { id: "7", type: "hospital", lat: 28.4595, lng: 77.0266, label: "Fortis Hospital", detail: "Emergency department open 24/7" },
  { id: "8", type: "police", lat: 28.7041, lng: 77.1025, label: "Police Station — Rohini", detail: "Response team active" },
];

const markerConfig: Record<MarkerType, { icon: typeof Shield; bg: string; ring: string }> = {
  safe: { icon: Shield, bg: "bg-emerald-500/90", ring: "ring-emerald-400/50" },
  hospital: { icon: Heart, bg: "bg-rose-500/90", ring: "ring-rose-400/50" },
  police: { icon: Shield, bg: "bg-indigo-500/90", ring: "ring-indigo-400/50" },
  fire: { icon: Siren, bg: "bg-amber-500/90", ring: "ring-amber-400/50" },
  shelter: { icon: Building2, bg: "bg-blue-500/90", ring: "ring-blue-400/50" },
  user: { icon: MapPin, bg: "bg-blue-600", ring: "ring-blue-400" },
};

const filterOptions: { id: MarkerType | "all"; label: string }[] = [
  { id: "all", label: "All" }, { id: "safe", label: "Safe Zones" }, { id: "hospital", label: "Hospitals" }, { id: "police", label: "Police" }, { id: "fire", label: "Fire" }, { id: "shelter", label: "Shelters" },
];

export default function MapView({ userLocation, gpsStatus, onEnableLocation }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<any>(null);
  const markerLayer = useRef<any>(null);
  const userMarkerRef = useRef<any>(null);
  const [activeFilter, setActiveFilter] = useState<MarkerType | "all">("all");
  const [selected, setSelected] = useState<MapMarker | null>(null);
  const [leafletReady, setLeafletReady] = useState(false);

  useEffect(() => {
    if ((window as any).L) { setLeafletReady(true); return; }
    const link = document.createElement("link");
    link.rel = "stylesheet"; link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    script.onload = () => setLeafletReady(true);
    document.body.appendChild(script);
    return () => { document.head.removeChild(link); document.body.removeChild(script); };
  }, []);

  useEffect(() => {
    if (!leafletReady || !mapRef.current || leafletMap.current) return;
    const L = (window as any).L;
    leafletMap.current = L.map(mapRef.current, { zoomControl: false, attributionControl: false }).setView(DELHI_CENTER, 12);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(leafletMap.current);
    markerLayer.current = L.layerGroup().addTo(leafletMap.current);
    return () => { leafletMap.current?.remove(); leafletMap.current = null; };
  }, [leafletReady]);

  useEffect(() => {
    if (!leafletMap.current || !markerLayer.current) return;
    const L = (window as any).L;
    markerLayer.current.clearLayers();
    markers.filter((m) => activeFilter === "all" || m.type === activeFilter).forEach((marker) => {
      const icon = L.divIcon({
        className: "aether-marker",
        html: `<div class="relative flex items-center justify-center"><span class="absolute h-8 w-8 animate-ping rounded-full ${markerConfig[marker.type].bg} opacity-40"></span><span class="relative flex h-8 w-8 items-center justify-center rounded-full ${markerConfig[marker.type].bg} ring-2 ${markerConfig[marker.type].ring} shadow-lg"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">${getIconPath(marker.type)}</svg></span></div>`,
        iconSize: [32, 32], iconAnchor: [16, 16],
      });
      const m = L.marker([marker.lat, marker.lng], { icon }).addTo(markerLayer.current);
      m.on("click", () => setSelected(marker));
    });
  }, [activeFilter, leafletReady]);

  useEffect(() => {
    if (!leafletMap.current || !userLocation) return;
    const L = (window as any).L;
    if (userMarkerRef.current) { userMarkerRef.current.setLatLng([userLocation.lat, userLocation.lng]); }
    else {
      const icon = L.divIcon({
        className: "aether-user-marker",
        html: `<div class="relative flex items-center justify-center"><span class="absolute h-6 w-6 animate-ping rounded-full bg-blue-500 opacity-60"></span><span class="relative h-3 w-3 rounded-full bg-blue-500 ring-4 ring-blue-300/40 shadow-lg"></span></div>`,
        iconSize: [24, 24], iconAnchor: [12, 12],
      });
      userMarkerRef.current = L.marker([userLocation.lat, userLocation.lng], { icon }).addTo(leafletMap.current);
    }
    leafletMap.current.setView([userLocation.lat, userLocation.lng], 14, { animate: true });
  }, [userLocation]);

  const flyToUser = () => { if (userLocation && leafletMap.current) leafletMap.current.flyTo([userLocation.lat, userLocation.lng], 15, { duration: 1.2 }); };
  const zoom = (dir: "in" | "out") => { if (!leafletMap.current) return; dir === "in" ? leafletMap.current.zoomIn() : leafletMap.current.zoomOut(); };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div><h2 className="font-serif text-2xl font-bold text-white">Emergency Map</h2><p className="text-sm text-slate-400">Safe zones, hospitals, and emergency services near you</p></div>
        <Badge className="bg-emerald-500/15 text-emerald-400 border-emerald-500/30"><span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-emerald-400" />Live</Badge>
      </div>

      <div className="flex flex-wrap gap-2">
        {filterOptions.map((opt) => (
          <button key={opt.id} onClick={() => setActiveFilter(opt.id)} className={cn("rounded-full border px-3 py-1.5 text-xs font-medium transition-all", activeFilter === opt.id ? "border-blue-500/40 bg-blue-500/20 text-blue-300" : "border-white/5 bg-white/5 text-slate-400 hover:bg-white/10")}>{opt.label}</button>
        ))}
      </div>

      <div className="relative overflow-hidden rounded-3xl border border-white/5 bg-slate-900 shadow-2xl">
        <div ref={mapRef} className="h-[500px] w-full" style={{ background: "#1a1f2e" }} />

        <div className="absolute right-4 top-4 flex flex-col gap-2">
          <button onClick={() => zoom("in")} className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-slate-900/80 text-white backdrop-blur-md transition-colors hover:bg-slate-800" aria-label="Zoom in"><Plus className="h-5 w-5" /></button>
          <button onClick={() => zoom("out")} className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-slate-900/80 text-white backdrop-blur-md transition-colors hover:bg-slate-800" aria-label="Zoom out"><Minus className="h-5 w-5" /></button>
          <button onClick={flyToUser} disabled={!userLocation} className="flex h-10 w-10 items-center justify-center rounded-xl border border-blue-500/30 bg-blue-600/80 text-white backdrop-blur-md transition-colors hover:bg-blue-500 disabled:opacity-40" aria-label="Find my location"><Navigation className="h-5 w-5" /></button>
        </div>

        {gpsStatus === "denied" && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm">
            <div className="mx-4 max-w-sm rounded-2xl border border-white/10 bg-slate-900 p-6 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/10"><MapPin className="h-6 w-6 text-amber-400" /></div>
              <h3 className="mt-3 font-semibold text-white">We need your location to help</h3>
              <p className="mt-1 text-sm text-slate-400">Enable location access to see emergency resources near you and share your position with responders if needed.</p>
              <Button onClick={onEnableLocation} className="mt-4 w-full bg-blue-600 hover:bg-blue-500">Enable GPS</Button>
            </div>
          </div>
        )}

        {!leafletReady && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950">
            <div className="flex flex-col items-center gap-3"><div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" /><p className="text-sm text-slate-400">Loading map...</p></div>
          </div>
        )}

        {selected && (
          <motion.div initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 100, opacity: 0 }} className="absolute bottom-0 left-0 right-0 border-t border-white/10 bg-slate-900/95 backdrop-blur-xl">
            <div className="flex items-start gap-3 p-4">
              <div className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-xl", markerConfig[selected.type].bg)}>
                {(() => { const Icon = markerConfig[selected.type].icon; return <Icon className="h-6 w-6 text-white" />; })()}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-white">{selected.label}</h3>
                <p className="text-sm text-slate-400">{selected.detail}</p>
                <div className="mt-2 flex items-center gap-1 text-xs text-slate-500"><MapPin className="h-3 w-3" />{selected.lat.toFixed(4)}, {selected.lng.toFixed(4)}</div>
              </div>
              <button onClick={() => setSelected(null)} className="rounded-lg p-1 text-slate-500 hover:bg-white/5 hover:text-white" aria-label="Close"><Minus className="h-4 w-4" /></button>
            </div>
          </motion.div>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-white/5 bg-white/5 p-4">
        <span className="text-xs font-medium text-slate-400">Legend:</span>
        {(["safe", "hospital", "police", "fire", "shelter"] as MarkerType[]).map((type) => {
          const config = markerConfig[type]; const Icon = config.icon;
          return (
            <div key={type} className="flex items-center gap-1.5">
              <div className={cn("flex h-5 w-5 items-center justify-center rounded-full", config.bg)}><Icon className="h-3 w-3 text-white" /></div>
              <span className="text-xs text-slate-300 capitalize">{type === "safe" ? "Safe Zone" : type}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function getIconPath(type: MarkerType): string {
  const paths: Record<MarkerType, string> = {
    safe: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    hospital: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"/>',
    police: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    fire: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
    shelter: '<path d="M3 9.5L12 2l9 7.5"/><path d="M5 10v10h14V10"/>',
    user: '<circle cx="12" cy="12" r="10"/>',
  };
  return paths[type];
}