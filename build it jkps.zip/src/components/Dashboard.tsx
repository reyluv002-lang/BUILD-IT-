import { motion } from "framer-motion";
import { AlertTriangle, MapPin, Users, Activity, Shield, Droplets, Heart, Building2, Siren, TrendingUp, ArrowRight, CloudRain, Radio, MapPinned } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type GpsStatus = "checking" | "granted" | "denied";

interface DashboardProps {
  gpsStatus: GpsStatus;
  online: boolean;
  userLocation: { lat: number; lng: number } | null;
  onNavigate: (view: "home" | "map" | "chat" | "community" | "profile") => void;
  onEnableLocation: () => void;
}

const stats = [
  { label: "Active Alerts", value: "12", change: "+3", icon: AlertTriangle, tone: "text-rose-400 bg-rose-500/10" },
  { label: "Safe Zones", value: "8", change: "+1", icon: Shield, tone: "text-emerald-400 bg-emerald-500/10" },
  { label: "Volunteers", value: "342", change: "+18", icon: Users, tone: "text-blue-400 bg-blue-500/10" },
  { label: "People Safe", value: "1.2k", change: "+47", icon: Heart, tone: "text-amber-400 bg-amber-500/10" },
];

const alerts = [
  { type: "Flood Warning", area: "Yamuna Bank, East Delhi", severity: "high", time: "5 min ago" },
  { type: "Power Outage", area: "Sector 14, Noida", severity: "medium", time: "22 min ago" },
  { type: "Medical Camp Open", area: "Connaught Place", severity: "info", time: "1 hour ago" },
  { type: "Road Closure", area: "Ring Road, NH-48", severity: "medium", time: "2 hours ago" },
];

const quickActions = [
  { label: "Find Shelter", icon: Building2, tone: "from-blue-500/20 to-blue-600/5", iconColor: "text-blue-400" },
  { label: "Hospitals", icon: Heart, tone: "from-rose-500/20 to-rose-600/5", iconColor: "text-rose-400" },
  { label: "Police", icon: Shield, tone: "from-indigo-500/20 to-indigo-600/5", iconColor: "text-indigo-400" },
  { label: "Fire Dept", icon: Siren, tone: "from-amber-500/20 to-amber-600/5", iconColor: "text-amber-400" },
];

const severityConfig = {
  high: { label: "High", className: "bg-rose-500/15 text-rose-400 border-rose-500/30" },
  medium: { label: "Medium", className: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
  info: { label: "Info", className: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
};

export default function Dashboard({ gpsStatus, online, userLocation, onNavigate, onEnableLocation }: DashboardProps) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="relative overflow-hidden rounded-3xl border border-white/5 bg-gradient-to-br from-blue-600/20 via-slate-900/40 to-slate-900/20 p-6 sm:p-8">
        <div className="absolute right-0 top-0 h-48 w-48 rounded-full bg-blue-500/10 blur-3xl" />
        <div className="relative">
          <p className="text-sm font-medium text-blue-400">{greeting}, Aanya</p>
          <h1 className="mt-1 font-serif text-3xl font-bold text-white sm:text-4xl">Stay informed. Stay safe.</h1>
          <p className="mt-2 max-w-lg text-sm text-slate-400">Real-time emergency coordination for Delhi NCR. Your community is connected and ready to respond.</p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <div className={cn("flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium", gpsStatus === "granted" ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400" : gpsStatus === "checking" ? "border-amber-500/30 bg-amber-500/10 text-amber-400" : "border-rose-500/30 bg-rose-500/10 text-rose-400")}>
              <MapPinned className="h-3.5 w-3.5" />
              {gpsStatus === "granted" ? `Location: ${userLocation?.lat.toFixed(2)}, ${userLocation?.lng.toFixed(2)}` : gpsStatus === "checking" ? "Acquiring location..." : "Location access denied"}
            </div>
            {gpsStatus === "denied" && <Button size="sm" variant="outline" onClick={onEnableLocation} className="border-white/10 bg-white/5 text-white hover:bg-white/10">Enable GPS</Button>}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="border-white/5 bg-white/5 backdrop-blur-sm transition-all hover:scale-[1.02] hover:bg-white/[0.07] hover:shadow-xl">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start justify-between">
                    <div className={cn("flex h-10 w-10 items-center justify-center rounded-xl", stat.tone)}><Icon className="h-5 w-5" /></div>
                    <span className="flex items-center gap-0.5 text-xs font-medium text-emerald-400"><TrendingUp className="h-3 w-3" />{stat.change}</span>
                  </div>
                  <div className="mt-3 font-serif text-2xl font-bold text-white sm:text-3xl">{stat.value}</div>
                  <div className="text-xs text-slate-400">{stat.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div>
        <h2 className="mb-3 font-serif text-lg font-semibold text-white">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quickActions.map((action, i) => {
            const Icon = action.icon;
            return (
              <motion.button key={action.label} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }} whileHover={{ scale: 1.03, y: -2 }} whileTap={{ scale: 0.98 }} onClick={() => onNavigate("map")} className={cn("group relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br p-4 text-left transition-all hover:shadow-lg", action.tone)}>
                <Icon className={cn("h-6 w-6 transition-transform group-hover:scale-110", action.iconColor)} />
                <p className="mt-3 text-sm font-semibold text-white">{action.label}</p>
                <ArrowRight className="absolute right-3 top-3 h-4 w-4 text-slate-500 transition-transform group-hover:translate-x-1" />
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="border-white/5 bg-white/5 backdrop-blur-sm lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="font-serif text-lg text-white">Recent Alerts</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("map")} className="text-blue-400 hover:bg-blue-500/10 hover:text-blue-300">View all <ArrowRight className="ml-1 h-3.5 w-3.5" /></Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {alerts.map((alert, i) => {
              const config = severityConfig[alert.severity as keyof typeof severityConfig];
              return (
                <motion.div key={alert.type} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} className="flex items-center gap-3 rounded-xl border border-white/5 bg-white/[0.03] p-3 transition-colors hover:bg-white/[0.06]">
                  <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg", config.className)}><AlertTriangle className="h-4 w-4" /></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white">{alert.type}</p>
                    <p className="flex items-center gap-1 text-xs text-slate-400"><MapPin className="h-3 w-3" />{alert.area}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge variant="outline" className={cn("border", config.className)}>{config.label}</Badge>
                    <span className="text-xs text-slate-500">{alert.time}</span>
                  </div>
                </motion.div>
              );
            })}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card className="border-white/5 bg-gradient-to-br from-blue-600/15 to-slate-900/30 backdrop-blur-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-slate-300">Delhi NCR</span>
                <CloudRain className="h-5 w-5 text-blue-400" />
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="font-serif text-4xl font-bold text-white">28°</span>
                <span className="text-sm text-slate-400">Light rain expected</span>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-white/5 p-2"><Droplets className="mx-auto h-4 w-4 text-blue-400" /><p className="mt-1 text-xs font-semibold text-white">78%</p><p className="text-xs text-slate-500">Humidity</p></div>
                <div className="rounded-lg bg-white/5 p-2"><Activity className="mx-auto h-4 w-4 text-emerald-400" /><p className="mt-1 text-xs font-semibold text-white">Moderate</p><p className="text-xs text-slate-500">AQI</p></div>
                <div className="rounded-lg bg-white/5 p-2"><Radio className="mx-auto h-4 w-4 text-amber-400" /><p className="mt-1 text-xs font-semibold text-white">Stable</p><p className="text-xs text-slate-500">Network</p></div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-white/5 backdrop-blur-sm">
            <CardHeader><CardTitle className="font-serif text-lg text-white">Community Activity</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {[
                { user: "Rajesh K.", action: "marked themselves safe at Shelter 3", time: "3m" },
                { user: "Dr. Meera", action: "opened a medical camp at CP", time: "12m" },
                { user: "Vikram S.", action: "reported a road closure on NH-48", time: "28m" },
              ].map((act) => (
                <div key={act.user} className="flex items-start gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-xs font-semibold text-white">{act.user.charAt(0)}</div>
                  <div className="flex-1">
                    <p className="text-sm text-slate-200"><span className="font-semibold text-white">{act.user}</span> {act.action}</p>
                    <p className="text-xs text-slate-500">{act.time} ago</p>
                  </div>
                </div>
              ))}
              <Button variant="ghost" size="sm" onClick={() => onNavigate("community")} className="w-full text-blue-400 hover:bg-blue-500/10 hover:text-blue-300">View community feed</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}