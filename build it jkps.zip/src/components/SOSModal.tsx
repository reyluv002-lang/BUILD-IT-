import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Siren, MapPin, X, CheckCircle2, AlertTriangle, Phone, Shield, Activity, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface SOSModalProps {
  open: boolean;
  onClose: () => void;
  userLocation: { lat: number; lng: number } | null;
}

const emergencyTypes = [
  { id: "medical", label: "Medical Emergency", icon: Activity },
  { id: "fire", label: "Fire / Smoke", icon: Siren },
  { id: "flood", label: "Flood / Water", icon: AlertTriangle },
  { id: "trapped", label: "Trapped / Need Rescue", icon: Shield },
  { id: "other", label: "Other Emergency", icon: Phone },
];

const alertHistory = [
  { type: "Medical", time: "2 days ago", status: "Resolved", location: "Sector 12" },
  { type: "Fire", time: "1 week ago", status: "Resolved", location: "Connaught Place" },
];

export default function SOSModal({ open, onClose, userLocation }: SOSModalProps) {
  const [selectedType, setSelectedType] = useState<string>("medical");
  const [phase, setPhase] = useState<"select" | "sending" | "sent">("select");
  const [countdown, setCountdown] = useState(3);

  useEffect(() => { if (!open) { setPhase("select"); setCountdown(3); } }, [open]);

  useEffect(() => {
    if (phase !== "sending") return;
    if (countdown <= 0) { setPhase("sent"); return; }
    const timer = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [phase, countdown]);

  const handleSend = () => { setPhase("sending"); setCountdown(3); };

  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose} />
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }} transition={{ type: "spring", stiffness: 300, damping: 30 }} className="relative w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-slate-900 shadow-2xl">
            <div className="relative flex items-center justify-between border-b border-white/5 bg-gradient-to-r from-rose-600/20 to-red-600/10 p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/20"><Siren className="h-5 w-5 text-rose-400" /></div>
                <div><h2 className="font-serif text-lg font-bold text-white">Emergency SOS</h2><p className="text-xs text-slate-400">This will alert nearby responders</p></div>
              </div>
              <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-white/5 hover:text-white" aria-label="Close"><X className="h-5 w-5" /></button>
            </div>

            <AnimatePresence mode="wait">
              {phase === "select" && (
                <motion.div key="select" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-5">
                  <div className="mb-4 flex items-center gap-2 rounded-xl border border-white/5 bg-white/5 p-3">
                    <MapPin className="h-4 w-4 text-blue-400" />
                    <div className="flex-1">
                      <p className="text-xs text-slate-400">Your location</p>
                      <p className="text-sm font-medium text-white">{userLocation ? `${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)}` : "Location not available — enable GPS to share"}</p>
                    </div>
                  </div>
                  <p className="mb-3 text-sm font-medium text-slate-300">What kind of emergency?</p>
                  <RadioGroup value={selectedType} onValueChange={setSelectedType} className="grid grid-cols-1 gap-2">
                    {emergencyTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <Label key={type.id} htmlFor={type.id} className={cn("flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition-all", selectedType === type.id ? "border-rose-500/40 bg-rose-500/10" : "border-white/5 bg-white/5 hover:bg-white/[0.07]")}>
                          <RadioGroupItem value={type.id} id={type.id} className="border-rose-500 text-rose-500" />
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5"><Icon className="h-4 w-4 text-slate-300" /></div>
                          <span className="text-sm font-medium text-white">{type.label}</span>
                        </Label>
                      );
                    })}
                  </RadioGroup>
                  <Button onClick={handleSend} className="mt-5 w-full bg-gradient-to-r from-rose-500 to-red-600 text-white hover:from-rose-600 hover:to-red-700" size="lg"><Send className="mr-2 h-4 w-4" />Send SOS Alert</Button>
                  <div className="mt-5">
                    <p className="mb-2 text-xs font-medium text-slate-400">Your recent alerts</p>
                    <div className="space-y-2">
                      {alertHistory.map((alert, i) => (
                        <div key={i} className="flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.03] p-2.5">
                          <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-400" /><span className="text-sm text-slate-300">{alert.type}</span><span className="text-xs text-slate-500">· {alert.location}</span></div>
                          <span className="text-xs text-slate-500">{alert.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {phase === "sending" && (
                <motion.div key="sending" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center p-12 text-center">
                  <div className="relative flex h-32 w-32 items-center justify-center">
                    <span className="absolute h-full w-full animate-ping rounded-full bg-rose-500/30" />
                    <span className="absolute h-24 w-24 animate-ping rounded-full bg-rose-500/40" style={{ animationDelay: "0.2s" }} />
                    <span className="relative font-serif text-5xl font-bold text-rose-400">{countdown}</span>
                  </div>
                  <h3 className="mt-6 font-serif text-xl font-bold text-white">Sending your alert...</h3>
                  <p className="mt-1 text-sm text-slate-400">Broadcasting your location to nearby responders</p>
                </motion.div>
              )}

              {phase === "sent" && (
                <motion.div key="sent" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center p-12 text-center">
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, delay: 0.1 }} className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500/20"><CheckCircle2 className="h-10 w-10 text-emerald-400" /></motion.div>
                  <h3 className="mt-5 font-serif text-xl font-bold text-white">Help is on the way</h3>
                  <p className="mt-1 max-w-xs text-sm text-slate-400">Emergency responders have been notified of your location. Stay where you are if it's safe.</p>
                  <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-2"><Phone className="h-4 w-4 text-emerald-400" /><span className="text-sm font-medium text-emerald-300">Estimated response: 8 minutes</span></div>
                  <Button onClick={onClose} variant="outline" className="mt-6 border-white/10 bg-white/5 text-white hover:bg-white/10">Close</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}