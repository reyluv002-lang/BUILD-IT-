import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Bookmark, MessageCircle, Share2, AlertTriangle, Users, Droplets, Siren, MapPin, Flag, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface Post {
  id: string; author: string; avatar: string; category: "emergency" | "volunteer" | "update" | "resource";
  time: string; location: string; title: string; content: string;
  likes: number; comments: number; liked?: boolean; bookmarked?: boolean; urgent?: boolean;
}

const initialPosts: Post[] = [
  { id: "1", author: "Rajesh Kumar", avatar: "RK", category: "emergency", time: "5 min ago", location: "Yamuna Bank, East Delhi", title: "Flood water rising near Yamuna Bank", content: "Water level has gone up a lot in the last hour. Please avoid the area and move to higher ground if you're nearby. The shelter at Sector 12 community center is open and taking people in.", likes: 142, comments: 38, urgent: true },
  { id: "2", author: "Dr. Meera Sharma", avatar: "MS", category: "volunteer", time: "22 min ago", location: "Connaught Place", title: "Medical camp set up at CP — we need volunteers", content: "We've set up a medical camp near the inner circle. Looking for 3 more volunteers with first aid training. Supplies are already on site. Shift starts at 2 PM, come whenever you can.", likes: 89, comments: 24 },
  { id: "3", author: "Vikram Singh", avatar: "VS", category: "update", time: "1 hour ago", location: "Ring Road, NH-48", title: "NH-48 is closed due to waterlogging", content: "Heavy waterlogging between Dhaula Kuan and the Gurugram border. Traffic is being diverted — use MG Road instead. Heard it might clear up by evening but don't count on it.", likes: 67, comments: 12 },
  { id: "4", author: "Priya Gupta", avatar: "PG", category: "resource", time: "2 hours ago", location: "Dwarka Sector 8", title: "Free food and water at Dwarka Sector 8 park", content: "Our community kitchen is handing out free meals and water bottles at the Sector 8 park. We're there from 12 PM to 6 PM. Please bring your own containers if you can — it helps us serve more people.", likes: 203, comments: 45 },
  { id: "5", author: "Arjun Mehta", avatar: "AM", category: "emergency", time: "3 hours ago", location: "Lajpat Nagar", title: "Power's been out in Lajpat Nagar for 4 hours", content: "No electricity in the Lajpat Nagar market area since this morning. BSES team is on site and says it should be back by 4 PM. There are charging stations at the community center if your phone is dying.", likes: 54, comments: 18 },
];

const categoryConfig = {
  emergency: { label: "Emergency", icon: AlertTriangle, className: "bg-rose-500/15 text-rose-400 border-rose-500/30" },
  volunteer: { label: "Volunteer", icon: Users, className: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  update: { label: "Update", icon: Droplets, className: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
  resource: { label: "Resource", icon: Siren, className: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
};

const filters = ["all", "emergency", "volunteer", "update", "resource"] as const;

export default function CommunityFeed() {
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [activeFilter, setActiveFilter] = useState<typeof filters[number]>("all");

  const toggleLike = (id: string) => setPosts((prev) => prev.map((p) => p.id === id ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p));
  const toggleBookmark = (id: string) => setPosts((prev) => prev.map((p) => p.id === id ? { ...p, bookmarked: !p.bookmarked } : p));
  const filteredPosts = posts.filter((p) => activeFilter === "all" || p.category === activeFilter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div><h2 className="font-serif text-2xl font-bold text-white">Community Feed</h2><p className="text-sm text-slate-400">Real-time updates from people around you</p></div>
        <Button className="bg-blue-600 hover:bg-blue-500"><span className="mr-1.5">+</span> New Post</Button>
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <Filter className="h-4 w-4 shrink-0 text-slate-500" />
        {filters.map((f) => (
          <button key={f} onClick={() => setActiveFilter(f)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-xs font-medium capitalize transition-all", activeFilter === f ? "border-blue-500/40 bg-blue-500/20 text-blue-300" : "border-white/5 bg-white/5 text-slate-400 hover:bg-white/10")}>{f}</button>
        ))}
      </div>

      <div className="space-y-4">
        <AnimatePresence mode="popLayout">
          {filteredPosts.map((post, i) => {
            const config = categoryConfig[post.category]; const Icon = config.icon;
            return (
              <motion.div key={post.id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ delay: i * 0.05 }} className="overflow-hidden rounded-2xl border border-white/5 bg-white/5 backdrop-blur-sm transition-all hover:border-white/10 hover:bg-white/[0.07] hover:shadow-xl">
                <div className="flex items-start gap-3 p-4 sm:p-5">
                  <Avatar className="h-11 w-11 border-2 border-white/10"><AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 font-semibold text-white">{post.avatar}</AvatarFallback></Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-white">{post.author}</span>
                      <span className="text-xs text-slate-500">· {post.time}</span>
                      {post.urgent && <Badge className="animate-pulse bg-rose-500/20 text-rose-400 border-rose-500/40"><span className="mr-1 h-1.5 w-1.5 rounded-full bg-rose-400" />Urgent</Badge>}
                    </div>
                    <div className="mt-1 flex items-center gap-1 text-xs text-slate-500"><MapPin className="h-3 w-3" />{post.location}</div>
                  </div>
                  <Badge variant="outline" className={cn("border", config.className)}><Icon className="mr-1 h-3 w-3" />{config.label}</Badge>
                </div>

                <div className="px-4 pb-3 sm:px-5">
                  <h3 className="font-serif text-lg font-bold text-white">{post.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-300">{post.content}</p>
                </div>

                <div className="mx-4 mb-3 h-40 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 sm:mx-5">
                  <div className="flex h-full items-center justify-center">
                    <div className="text-center">
                      <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-lg bg-white/5"><Droplets className="h-5 w-5 text-slate-600" /></div>
                      <p className="mt-2 text-xs text-slate-600">Image attachment</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 border-t border-white/5 px-4 py-2 sm:px-5">
                  <button onClick={() => toggleLike(post.id)} className={cn("flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors", post.liked ? "text-rose-400" : "text-slate-400 hover:bg-white/5 hover:text-white")} aria-label={post.liked ? "Unlike" : "Like"}>
                    <Heart className={cn("h-4 w-4", post.liked && "fill-current")} />{post.likes}
                  </button>
                  <button className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition-colors hover:bg-white/5 hover:text-white"><MessageCircle className="h-4 w-4" />{post.comments}</button>
                  <button onClick={() => toggleBookmark(post.id)} className={cn("flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors", post.bookmarked ? "text-blue-400" : "text-slate-400 hover:bg-white/5 hover:text-white")} aria-label={post.bookmarked ? "Remove bookmark" : "Bookmark"}>
                    <Bookmark className={cn("h-4 w-4", post.bookmarked && "fill-current")} />
                  </button>
                  <button className="ml-auto flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition-colors hover:bg-white/5 hover:text-white"><Share2 className="h-4 w-4" /></button>
                  <button className="flex items-center rounded-lg p-2 text-slate-500 transition-colors hover:bg-white/5 hover:text-rose-400" aria-label="Report post"><Flag className="h-4 w-4" /></button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {filteredPosts.length === 0 && (
        <div className="rounded-2xl border border-white/5 bg-white/5 p-12 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800"><MessageCircle className="h-6 w-6 text-slate-500" /></div>
          <h3 className="mt-3 font-semibold text-white">No posts here yet</h3>
          <p className="mt-1 text-sm text-slate-400">Be the first to share an update in this category.</p>
        </div>
      )}
    </div>
  );
}