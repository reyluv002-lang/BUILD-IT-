import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, Search, Bell, Home, MapPin, MessageSquare, Users, User, Radio, Wifi, MapPinned } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import Dashboard from "@/components/Dashboard";
import MapView from "@/components/MapView";
import CommunityFeed from "@/components/CommunityFeed";
import SOSModal from "@/components/SOSModal";

type View = "home" | "map" | "chat" | "community" | "profile";

const navItems = [
  { id: "home", label: "Home", icon: Home },
  { id: "map", label: "Map", icon: MapPin },
  { id: "chat", label: "Chat", icon: MessageSquare },
  { id: "community", label: "Community", icon: Users },
  { id: "profile", label: "Profile", icon: User },
] as const;

export default function App() {
  const [view, setView] = useState<View>("home");
  const [sosOpen, setSosOpen] = useState(false);
  const [gpsStatus, setGpsStatus] = useState<"checking" | "granted" | "denied">("checking");
  const [online, setOnline] = useState(navigator.onLine);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    const updateOnline = () => setOnline(navigator.onLine);
    window.addEventListener("online", updateOnline);
    window.addEventListener("offline", updateOnline);
    return () => {
      window.removeEventListener("online", updateOnline);
      window.removeEventListener("offline", updateOnline);
    };
  }, []);

  const requestLocation = useCallback(() => {
    if (!navigator.geolocation) return setGpsStatus("denied");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGpsStatus("granted");
      },
      () => setGpsStatus("denied"),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, []);

  useEffect(() => { requestLocation(); }, [requestLocation]);

  const renderView = () => {
    switch (view) {
      case "home": return <Dashboard gpsStatus={gpsStatus} online={online} userLocation={userLocation} onNavigate={setView} onEnableLocation={requestLocation} />;
      case "map": return <MapView userLocation={userLocation} gpsStatus={gpsStatus} onEnableLocation={requestLocation} />;
      case "community": return <CommunityFeed />;
      case "chat": return <ChatPreview />;
      case "profile": return <ProfilePreview />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 antialiased">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 h-96 w-96 rounded-full bg-blue-600/20 blur-3xl" />
        <div className="absolute top-1/3 -right-40 h-96 w-96 rounded-full bg-indigo-600/10 blur-3xl" />
      </div>

      <header className="sticky top-0 z-40 border-b border-white/5 bg-slate-950/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
          <button onClick={() => setView("home")} className="flex items-center gap-2.5 transition-transform hover:scale-[1.02]">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg shadow-blue-500/30">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <span className="font-serif text-lg font-bold tracking-tight text-white">Aether</span>
              <span className="ml-1 font-serif text-lg font-light text-blue-400">Grid</span>
            </div>
          </button>

          <div className="relative ml-2 hidden flex-1 max-w-md md:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <Input placeholder="Search resources, alerts, people..." className="border-white/5 bg-white/5 pl-10 text-sm text-slate-200 placeholder:text-slate-500 focus:border-blue-500/50" />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <div className="hidden items-center gap-2 lg:flex">
              <StatusChip icon={Wifi} label={online ? "Online" : "Offline"} tone={online ? "success" : "danger"} />
              <StatusChip icon={MapPinned} label={gpsStatus === "granted" ? "GPS Active" : gpsStatus === "checking" ? "Locating..." : "GPS Off"} tone={gpsStatus === "granted" ? "success" : gpsStatus === "checking" ? "warning" : "danger"} />
            </div>
            <Button variant="ghost" size="icon" className="relative rounded-xl text-slate-300 hover:bg-white/5 hover:text-white">
              <Search className="h-5 w-5 md:hidden" />
              <Bell className="hidden h-5 w-5 md:block" />
              <span className="absolute right-1.5 top-1.5 flex h-2 w-2 rounded-full bg-rose-500 ring-2 ring-slate-950" />
            </Button>
            <button onClick={() => setView("profile")} className="transition-transform hover:scale-105">
              <Avatar className="h-9 w-9 border-2 border-blue-500/30">
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 text-sm font-semibold text-white">AR</AvatarFallback>
              </Avatar>
            </button>
          </div>
        </div>
      </header>

      <main className="relative mx-auto max-w-7xl px-4 pb-32 pt-6 sm:px-6 lg:px-8 lg:pb-12">
        <AnimatePresence mode="wait">
          <motion.div key={view} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25, ease: "easeOut" }}>
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      <motion.button initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} transition={{ delay: 0.3, type: "spring", stiffness: 200 }} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => setSosOpen(true)} className="fixed bottom-24 right-4 z-40 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-rose-500 to-red-600 shadow-2xl shadow-red-500/40 lg:bottom-8 lg:right-8" aria-label="Emergency SOS">
        <span className="absolute inset-0 animate-ping rounded-full bg-red-500/40" />
        <Radio className="relative h-7 w-7 text-white" />
      </motion.button>

      <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-white/5 bg-slate-950/90 backdrop-blur-xl lg:hidden">
        <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button key={item.id} onClick={() => setView(item.id)} className={cn("relative flex flex-1 flex-col items-center gap-1 rounded-lg py-2 text-xs transition-colors", active ? "text-blue-400" : "text-slate-500")}>
                {active && <motion.div layoutId="navIndicator" className="absolute -top-2 h-1 w-8 rounded-full bg-blue-500" />}
                <Icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      <SOSModal open={sosOpen} onClose={() => setSosOpen(false)} userLocation={userLocation} />
    </div>
  );
}

function StatusChip({ icon: Icon, label, tone }: { icon: typeof Wifi; label: string; tone: "success" | "warning" | "danger" }) {
  const tones = { success: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20", warning: "text-amber-400 bg-amber-500/10 border-amber-500/20", danger: "text-rose-400 bg-rose-500/10 border-rose-500/20" };
  return (
    <div className={cn("flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium", tones[tone])}>
      <Icon className="h-3.5 w-3.5" />{label}
    </div>
  );
}

function ChatPreview() {
  const conversations = [
    { name: "Emergency Response Team", last: "Shelter at Sector 12 is open now", time: "2m", unread: 3, pinned: true },
    { name: "Neighborhood Watch", last: "Power's back on 5th street", time: "15m", unread: 0 },
    { name: "Medical Volunteers", last: "Need O+ blood at City Hospital urgently", time: "1h", unread: 1 },
    { name: "Family Group", last: "Everyone's safe at home, don't worry", time: "2h", unread: 0 },
  ];
  return (
    <div className="space-y-4">
      <div><h2 className="font-serif text-2xl font-bold text-white">Messages</h2><p className="text-sm text-slate-400">Stay connected with your community</p></div>
      <div className="space-y-2">
        {conversations.map((c) => (
          <div key={c.name} className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/5 p-4 transition-all hover:scale-[1.01] hover:bg-white/[0.07] hover:shadow-lg">
            <Avatar className="h-12 w-12"><AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 font-semibold text-white">{c.name.charAt(0)}</AvatarFallback></Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-1.5 font-semibold text-white truncate">{c.pinned && <span className="text-xs text-blue-400">📌</span>}{c.name}</span>
                <span className="text-xs text-slate-500 shrink-0">{c.time}</span>
              </div>
              <p className="truncate text-sm text-slate-400">{c.last}</p>
            </div>
            {c.unread > 0 && <Badge className="bg-blue-500 text-white">{c.unread}</Badge>}
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfilePreview() {
  const menuItems = [
    { label: "Emergency Contacts", icon: Shield, hint: "3 contacts saved" },
    { label: "Medical Information", icon: Activity, hint: "Blood type, allergies" },
    { label: "Notification Preferences", icon: Bell, hint: "Alerts, updates" },
    { label: "Privacy & Location", icon: MapPin, hint: "Sharing settings" },
  ];
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="rounded-3xl border border-white/5 bg-gradient-to-br from-blue-600/20 to-indigo-700/10 p-8 text-center">
        <Avatar className="mx-auto h-24 w-24 border-4 border-blue-500/30"><AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 text-2xl font-bold text-white">AR</AvatarFallback></Avatar>
        <h2 className="mt-4 font-serif text-2xl font-bold text-white">Aanya Reddy</h2>
        <p className="text-sm text-slate-400">Community Volunteer · Delhi Sector 12</p>
        <div className="mt-6 flex justify-center gap-8">
          <div><div className="font-serif text-3xl font-bold text-white">24</div><div className="text-xs text-slate-400">Alerts Sent</div></div>
          <div className="border-l border-white/10 pl-8"><div className="font-serif text-3xl font-bold text-white">156</div><div className="text-xs text-slate-400">People Helped</div></div>
          <div className="border-l border-white/10 pl-8"><div className="font-serif text-3xl font-bold text-white">8</div><div className="text-xs text-slate-400">Safe Zones</div></div>
        </div>
      </div>
      <div className="space-y-3">
        {menuItems.map(({ label, icon: Icon, hint }) => (
          <div key={label} className="flex items-center gap-4 rounded-2xl border border-white/5 bg-white/5 p-4 transition-all hover:bg-white/[0.07]">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-500/10"><Icon className="h-5 w-5 text-blue-400" /></div>
            <div className="flex-1"><span className="block font-medium text-white">{label}</span><span className="text-xs text-slate-500">{hint}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}